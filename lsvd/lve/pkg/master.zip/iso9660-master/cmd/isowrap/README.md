### Usage

`isowrap < file > output.iso`
